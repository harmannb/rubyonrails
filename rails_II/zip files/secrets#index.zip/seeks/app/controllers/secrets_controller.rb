class SecretsController < ApplicationController


end

