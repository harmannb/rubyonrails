require 'test_helper'

class IdeasHelperTest < ActionView::TestCase
end
