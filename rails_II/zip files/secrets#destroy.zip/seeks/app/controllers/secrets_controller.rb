class SecretsController < ApplicationController
  def index
    @secret = Secret.all
  end

  def create
    @secret = Secret.create(content: params[:content], user: User.find(session[:user_id]))
    @user = User.find(session[:user_id])
    redirect_to "/users/#{@user.id}"
  end

  def destroy
    @user = User.find(session[:user_id])
    Secret.find(params[:id]).destroy
    redirect_to "/users/#{@user.id}"
  end

end

