class LikesController < ApplicationController

end
