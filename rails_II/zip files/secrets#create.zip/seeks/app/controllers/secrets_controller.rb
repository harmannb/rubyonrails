class SecretsController < ApplicationController
  def create
    @secret = Secret.create(content: params[:content], user: User.find(session[:user_id]))
    @user = User.find(session[:user_id])
    redirect_to "/users/#{@user.id}"
  end

end

