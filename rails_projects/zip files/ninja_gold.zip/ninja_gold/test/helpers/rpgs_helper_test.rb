require 'test_helper'

class RpgsHelperTest < ActionView::TestCase
end
