class Number
end
