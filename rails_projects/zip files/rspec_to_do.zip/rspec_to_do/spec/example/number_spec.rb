require 'rails_helper'
require 'number'
require 'rails_helper'
RSpec.describe "Number" do
  it "is a valid person's name"
  it "is a valid pet's name"
  it "is a valid age for a person"
  it "is a valid age for a pet"
end
