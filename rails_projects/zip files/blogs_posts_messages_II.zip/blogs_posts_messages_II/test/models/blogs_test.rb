require 'test_helper'

class BlogsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
