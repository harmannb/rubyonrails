require 'test_helper'

class OwnersTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
